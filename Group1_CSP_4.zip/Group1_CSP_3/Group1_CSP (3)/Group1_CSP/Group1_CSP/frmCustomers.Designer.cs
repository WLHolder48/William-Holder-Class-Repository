﻿namespace Group1_CSP
{
    partial class frmCustomers
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label20 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.lblApplesInventory = new System.Windows.Forms.Label();
            this.lblChickenInventory = new System.Windows.Forms.Label();
            this.lblMilkInventory = new System.Windows.Forms.Label();
            this.lblBreadInventory = new System.Windows.Forms.Label();
            this.lblSteakInventory = new System.Windows.Forms.Label();
            this.lblEggsInventory = new System.Windows.Forms.Label();
            this.lblOrangesInventory = new System.Windows.Forms.Label();
            this.lblCarrotsInventory = new System.Windows.Forms.Label();
            this.lblGrapesInventory = new System.Windows.Forms.Label();
            this.lblBananaInventory = new System.Windows.Forms.Label();
            this.btnCheckout = new System.Windows.Forms.Button();
            this.btnExit = new System.Windows.Forms.Button();
            this.label21 = new System.Windows.Forms.Label();
            this.pbxChicken = new System.Windows.Forms.PictureBox();
            this.pbxBananas = new System.Windows.Forms.PictureBox();
            this.pbxGrapes = new System.Windows.Forms.PictureBox();
            this.pbxCarrots = new System.Windows.Forms.PictureBox();
            this.pbxOranges = new System.Windows.Forms.PictureBox();
            this.pbxEggs = new System.Windows.Forms.PictureBox();
            this.pbxSteak = new System.Windows.Forms.PictureBox();
            this.pbxMilk = new System.Windows.Forms.PictureBox();
            this.pbxBread = new System.Windows.Forms.PictureBox();
            this.pbxApples = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pbxChicken)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxBananas)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxGrapes)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxCarrots)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxOranges)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxEggs)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxSteak)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxMilk)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxBread)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxApples)).BeginInit();
            this.SuspendLayout();
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label20.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.ForeColor = System.Drawing.Color.White;
            this.label20.Location = new System.Drawing.Point(587, 297);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(49, 20);
            this.label20.TabIndex = 61;
            this.label20.Text = "$4.50";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label19.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.ForeColor = System.Drawing.Color.White;
            this.label19.Location = new System.Drawing.Point(152, 108);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(49, 20);
            this.label19.TabIndex = 60;
            this.label19.Text = "$0.75";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label18.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.ForeColor = System.Drawing.Color.White;
            this.label18.Location = new System.Drawing.Point(297, 108);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(49, 20);
            this.label18.TabIndex = 59;
            this.label18.Text = "$0.80";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label17.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.ForeColor = System.Drawing.Color.White;
            this.label17.Location = new System.Drawing.Point(442, 108);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(49, 20);
            this.label17.TabIndex = 58;
            this.label17.Text = "$1.00";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.ForeColor = System.Drawing.Color.White;
            this.label16.Location = new System.Drawing.Point(587, 108);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(49, 20);
            this.label16.TabIndex = 57;
            this.label16.Text = "$0.50";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.ForeColor = System.Drawing.Color.White;
            this.label15.Location = new System.Drawing.Point(11, 297);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(49, 20);
            this.label15.TabIndex = 56;
            this.label15.Text = "$3.50";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.ForeColor = System.Drawing.Color.White;
            this.label14.Location = new System.Drawing.Point(152, 297);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(49, 20);
            this.label14.TabIndex = 55;
            this.label14.Text = "$5.00";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.ForeColor = System.Drawing.Color.White;
            this.label13.Location = new System.Drawing.Point(297, 297);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(49, 20);
            this.label13.TabIndex = 54;
            this.label13.Text = "$2.00";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.ForeColor = System.Drawing.Color.White;
            this.label12.Location = new System.Drawing.Point(442, 297);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(49, 20);
            this.label12.TabIndex = 53;
            this.label12.Text = "$3.00";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.Color.White;
            this.label11.Location = new System.Drawing.Point(12, 108);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(49, 20);
            this.label11.TabIndex = 52;
            this.label11.Text = "$0.50";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label10.Location = new System.Drawing.Point(487, 273);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(43, 24);
            this.label10.TabIndex = 51;
            this.label10.Text = "Milk";
            this.label10.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label9.Location = new System.Drawing.Point(620, 270);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(79, 24);
            this.label9.TabIndex = 50;
            this.label9.Text = "Chicken";
            this.label9.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label8.Location = new System.Drawing.Point(470, 81);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(69, 24);
            this.label8.TabIndex = 49;
            this.label8.Text = "Carrots";
            this.label8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label7.Location = new System.Drawing.Point(616, 81);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(83, 24);
            this.label7.TabIndex = 48;
            this.label7.Text = "Oranges";
            this.label7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label6.Location = new System.Drawing.Point(55, 270);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(54, 24);
            this.label6.TabIndex = 47;
            this.label6.Text = "Eggs";
            this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label5.Location = new System.Drawing.Point(190, 270);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(56, 24);
            this.label5.TabIndex = 46;
            this.label5.Text = "Steak";
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label4.Location = new System.Drawing.Point(338, 270);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(60, 24);
            this.label4.TabIndex = 45;
            this.label4.Text = "Bread";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label3.Location = new System.Drawing.Point(327, 81);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(71, 24);
            this.label3.TabIndex = 44;
            this.label3.Text = "Grapes";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label2.Location = new System.Drawing.Point(173, 81);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(83, 24);
            this.label2.TabIndex = 43;
            this.label2.Text = "Bananas";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label1.Location = new System.Drawing.Point(40, 81);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(69, 24);
            this.label1.TabIndex = 42;
            this.label1.Text = "Apples";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblApplesInventory
            // 
            this.lblApplesInventory.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lblApplesInventory.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblApplesInventory.ForeColor = System.Drawing.Color.White;
            this.lblApplesInventory.Location = new System.Drawing.Point(118, 225);
            this.lblApplesInventory.Name = "lblApplesInventory";
            this.lblApplesInventory.Size = new System.Drawing.Size(28, 23);
            this.lblApplesInventory.TabIndex = 62;
            this.lblApplesInventory.Text = "5";
            this.lblApplesInventory.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblChickenInventory
            // 
            this.lblChickenInventory.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lblChickenInventory.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblChickenInventory.ForeColor = System.Drawing.Color.White;
            this.lblChickenInventory.Location = new System.Drawing.Point(698, 414);
            this.lblChickenInventory.Name = "lblChickenInventory";
            this.lblChickenInventory.Size = new System.Drawing.Size(28, 23);
            this.lblChickenInventory.TabIndex = 63;
            this.lblChickenInventory.Text = "6";
            this.lblChickenInventory.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblMilkInventory
            // 
            this.lblMilkInventory.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lblMilkInventory.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMilkInventory.ForeColor = System.Drawing.Color.White;
            this.lblMilkInventory.Location = new System.Drawing.Point(553, 414);
            this.lblMilkInventory.Name = "lblMilkInventory";
            this.lblMilkInventory.Size = new System.Drawing.Size(28, 23);
            this.lblMilkInventory.TabIndex = 64;
            this.lblMilkInventory.Text = "3";
            this.lblMilkInventory.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblBreadInventory
            // 
            this.lblBreadInventory.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lblBreadInventory.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblBreadInventory.ForeColor = System.Drawing.Color.White;
            this.lblBreadInventory.Location = new System.Drawing.Point(408, 414);
            this.lblBreadInventory.Name = "lblBreadInventory";
            this.lblBreadInventory.Size = new System.Drawing.Size(28, 23);
            this.lblBreadInventory.TabIndex = 65;
            this.lblBreadInventory.Text = "7";
            this.lblBreadInventory.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblSteakInventory
            // 
            this.lblSteakInventory.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lblSteakInventory.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSteakInventory.ForeColor = System.Drawing.Color.White;
            this.lblSteakInventory.Location = new System.Drawing.Point(263, 414);
            this.lblSteakInventory.Name = "lblSteakInventory";
            this.lblSteakInventory.Size = new System.Drawing.Size(28, 23);
            this.lblSteakInventory.TabIndex = 66;
            this.lblSteakInventory.Text = "3";
            this.lblSteakInventory.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblEggsInventory
            // 
            this.lblEggsInventory.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lblEggsInventory.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEggsInventory.ForeColor = System.Drawing.Color.White;
            this.lblEggsInventory.Location = new System.Drawing.Point(118, 414);
            this.lblEggsInventory.Name = "lblEggsInventory";
            this.lblEggsInventory.Size = new System.Drawing.Size(28, 23);
            this.lblEggsInventory.TabIndex = 67;
            this.lblEggsInventory.Text = "10";
            this.lblEggsInventory.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblOrangesInventory
            // 
            this.lblOrangesInventory.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lblOrangesInventory.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblOrangesInventory.ForeColor = System.Drawing.Color.White;
            this.lblOrangesInventory.Location = new System.Drawing.Point(698, 225);
            this.lblOrangesInventory.Name = "lblOrangesInventory";
            this.lblOrangesInventory.Size = new System.Drawing.Size(28, 23);
            this.lblOrangesInventory.TabIndex = 68;
            this.lblOrangesInventory.Text = "6";
            this.lblOrangesInventory.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblCarrotsInventory
            // 
            this.lblCarrotsInventory.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lblCarrotsInventory.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCarrotsInventory.ForeColor = System.Drawing.Color.White;
            this.lblCarrotsInventory.Location = new System.Drawing.Point(553, 225);
            this.lblCarrotsInventory.Name = "lblCarrotsInventory";
            this.lblCarrotsInventory.Size = new System.Drawing.Size(28, 23);
            this.lblCarrotsInventory.TabIndex = 69;
            this.lblCarrotsInventory.Text = "5";
            this.lblCarrotsInventory.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblGrapesInventory
            // 
            this.lblGrapesInventory.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lblGrapesInventory.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblGrapesInventory.ForeColor = System.Drawing.Color.White;
            this.lblGrapesInventory.Location = new System.Drawing.Point(408, 225);
            this.lblGrapesInventory.Name = "lblGrapesInventory";
            this.lblGrapesInventory.Size = new System.Drawing.Size(28, 23);
            this.lblGrapesInventory.TabIndex = 70;
            this.lblGrapesInventory.Text = "4";
            this.lblGrapesInventory.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblBananaInventory
            // 
            this.lblBananaInventory.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lblBananaInventory.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblBananaInventory.ForeColor = System.Drawing.Color.White;
            this.lblBananaInventory.Location = new System.Drawing.Point(263, 225);
            this.lblBananaInventory.Name = "lblBananaInventory";
            this.lblBananaInventory.Size = new System.Drawing.Size(28, 23);
            this.lblBananaInventory.TabIndex = 71;
            this.lblBananaInventory.Text = "8";
            this.lblBananaInventory.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // btnCheckout
            // 
            this.btnCheckout.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCheckout.Location = new System.Drawing.Point(172, 472);
            this.btnCheckout.Name = "btnCheckout";
            this.btnCheckout.Size = new System.Drawing.Size(97, 39);
            this.btnCheckout.TabIndex = 72;
            this.btnCheckout.Text = "&Checkout";
            this.btnCheckout.UseVisualStyleBackColor = true;
            this.btnCheckout.Click += new System.EventHandler(this.btnCheckout_Click);
            // 
            // btnExit
            // 
            this.btnExit.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnExit.Location = new System.Drawing.Point(469, 472);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(97, 39);
            this.btnExit.TabIndex = 73;
            this.btnExit.Text = "E&xit";
            this.btnExit.UseVisualStyleBackColor = true;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label21.ForeColor = System.Drawing.Color.White;
            this.label21.Location = new System.Drawing.Point(30, 51);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(281, 18);
            this.label21.TabIndex = 74;
            this.label21.Text = "Click an item to add to your shopping cart\r\n";
            // 
            // pbxChicken
            // 
            this.pbxChicken.Image = global::Group1_CSP.Properties.Resources.chicken5;
            this.pbxChicken.Location = new System.Drawing.Point(591, 297);
            this.pbxChicken.Name = "pbxChicken";
            this.pbxChicken.Size = new System.Drawing.Size(135, 140);
            this.pbxChicken.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbxChicken.TabIndex = 41;
            this.pbxChicken.TabStop = false;
            this.pbxChicken.Click += new System.EventHandler(this.pbxChicken_Click);
            // 
            // pbxBananas
            // 
            this.pbxBananas.Image = global::Group1_CSP.Properties.Resources.bananas;
            this.pbxBananas.Location = new System.Drawing.Point(156, 108);
            this.pbxBananas.Name = "pbxBananas";
            this.pbxBananas.Size = new System.Drawing.Size(135, 140);
            this.pbxBananas.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbxBananas.TabIndex = 40;
            this.pbxBananas.TabStop = false;
            this.pbxBananas.Click += new System.EventHandler(this.pbxBananas_Click);
            // 
            // pbxGrapes
            // 
            this.pbxGrapes.Image = global::Group1_CSP.Properties.Resources.grapes;
            this.pbxGrapes.Location = new System.Drawing.Point(301, 108);
            this.pbxGrapes.Name = "pbxGrapes";
            this.pbxGrapes.Size = new System.Drawing.Size(135, 140);
            this.pbxGrapes.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbxGrapes.TabIndex = 39;
            this.pbxGrapes.TabStop = false;
            this.pbxGrapes.Click += new System.EventHandler(this.pbxGrapes_Click);
            // 
            // pbxCarrots
            // 
            this.pbxCarrots.Image = global::Group1_CSP.Properties.Resources.carrots;
            this.pbxCarrots.Location = new System.Drawing.Point(446, 108);
            this.pbxCarrots.Name = "pbxCarrots";
            this.pbxCarrots.Size = new System.Drawing.Size(135, 140);
            this.pbxCarrots.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbxCarrots.TabIndex = 38;
            this.pbxCarrots.TabStop = false;
            this.pbxCarrots.Click += new System.EventHandler(this.pbxCarrots_Click);
            // 
            // pbxOranges
            // 
            this.pbxOranges.Image = global::Group1_CSP.Properties.Resources.oranges;
            this.pbxOranges.Location = new System.Drawing.Point(591, 108);
            this.pbxOranges.Name = "pbxOranges";
            this.pbxOranges.Size = new System.Drawing.Size(135, 140);
            this.pbxOranges.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbxOranges.TabIndex = 37;
            this.pbxOranges.TabStop = false;
            this.pbxOranges.Click += new System.EventHandler(this.pbxOranges_Click);
            // 
            // pbxEggs
            // 
            this.pbxEggs.Image = global::Group1_CSP.Properties.Resources.eggs;
            this.pbxEggs.Location = new System.Drawing.Point(11, 297);
            this.pbxEggs.Name = "pbxEggs";
            this.pbxEggs.Size = new System.Drawing.Size(135, 140);
            this.pbxEggs.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbxEggs.TabIndex = 36;
            this.pbxEggs.TabStop = false;
            this.pbxEggs.Click += new System.EventHandler(this.pbxEggs_Click);
            // 
            // pbxSteak
            // 
            this.pbxSteak.Image = global::Group1_CSP.Properties.Resources.steak;
            this.pbxSteak.Location = new System.Drawing.Point(156, 297);
            this.pbxSteak.Name = "pbxSteak";
            this.pbxSteak.Size = new System.Drawing.Size(135, 140);
            this.pbxSteak.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbxSteak.TabIndex = 35;
            this.pbxSteak.TabStop = false;
            this.pbxSteak.Click += new System.EventHandler(this.pbxSteak_Click);
            // 
            // pbxMilk
            // 
            this.pbxMilk.Image = global::Group1_CSP.Properties.Resources.milk;
            this.pbxMilk.Location = new System.Drawing.Point(446, 297);
            this.pbxMilk.Name = "pbxMilk";
            this.pbxMilk.Size = new System.Drawing.Size(135, 140);
            this.pbxMilk.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbxMilk.TabIndex = 34;
            this.pbxMilk.TabStop = false;
            this.pbxMilk.Click += new System.EventHandler(this.pbxMilk_Click);
            // 
            // pbxBread
            // 
            this.pbxBread.Image = global::Group1_CSP.Properties.Resources.bread1;
            this.pbxBread.Location = new System.Drawing.Point(301, 297);
            this.pbxBread.Name = "pbxBread";
            this.pbxBread.Size = new System.Drawing.Size(135, 140);
            this.pbxBread.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbxBread.TabIndex = 33;
            this.pbxBread.TabStop = false;
            this.pbxBread.Click += new System.EventHandler(this.pbxBread_Click);
            // 
            // pbxApples
            // 
            this.pbxApples.ErrorImage = null;
            this.pbxApples.Image = global::Group1_CSP.Properties.Resources.apples2;
            this.pbxApples.InitialImage = null;
            this.pbxApples.Location = new System.Drawing.Point(11, 108);
            this.pbxApples.Name = "pbxApples";
            this.pbxApples.Size = new System.Drawing.Size(135, 140);
            this.pbxApples.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbxApples.TabIndex = 32;
            this.pbxApples.TabStop = false;
            this.pbxApples.Click += new System.EventHandler(this.pbxApples_Click);
            // 
            // frmCustomers
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.MidnightBlue;
            this.ClientSize = new System.Drawing.Size(739, 537);
            this.Controls.Add(this.label21);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.btnCheckout);
            this.Controls.Add(this.lblBananaInventory);
            this.Controls.Add(this.lblGrapesInventory);
            this.Controls.Add(this.lblCarrotsInventory);
            this.Controls.Add(this.lblOrangesInventory);
            this.Controls.Add(this.lblEggsInventory);
            this.Controls.Add(this.lblSteakInventory);
            this.Controls.Add(this.lblBreadInventory);
            this.Controls.Add(this.lblMilkInventory);
            this.Controls.Add(this.lblChickenInventory);
            this.Controls.Add(this.lblApplesInventory);
            this.Controls.Add(this.label20);
            this.Controls.Add(this.label19);
            this.Controls.Add(this.label18);
            this.Controls.Add(this.label17);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.pbxChicken);
            this.Controls.Add(this.pbxBananas);
            this.Controls.Add(this.pbxGrapes);
            this.Controls.Add(this.pbxCarrots);
            this.Controls.Add(this.pbxOranges);
            this.Controls.Add(this.pbxEggs);
            this.Controls.Add(this.pbxSteak);
            this.Controls.Add(this.pbxMilk);
            this.Controls.Add(this.pbxBread);
            this.Controls.Add(this.pbxApples);
            this.Name = "frmCustomers";
            this.Text = "Customers";
            this.Load += new System.EventHandler(this.frmCustomers_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pbxChicken)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxBananas)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxGrapes)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxCarrots)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxOranges)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxEggs)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxSteak)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxMilk)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxBread)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxApples)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox pbxChicken;
        private System.Windows.Forms.PictureBox pbxBananas;
        private System.Windows.Forms.PictureBox pbxGrapes;
        private System.Windows.Forms.PictureBox pbxCarrots;
        private System.Windows.Forms.PictureBox pbxOranges;
        private System.Windows.Forms.PictureBox pbxEggs;
        private System.Windows.Forms.PictureBox pbxSteak;
        private System.Windows.Forms.PictureBox pbxMilk;
        private System.Windows.Forms.PictureBox pbxBread;
        private System.Windows.Forms.PictureBox pbxApples;
        private System.Windows.Forms.Label lblApplesInventory;
        private System.Windows.Forms.Label lblChickenInventory;
        private System.Windows.Forms.Label lblMilkInventory;
        private System.Windows.Forms.Label lblBreadInventory;
        private System.Windows.Forms.Label lblSteakInventory;
        private System.Windows.Forms.Label lblEggsInventory;
        private System.Windows.Forms.Label lblOrangesInventory;
        private System.Windows.Forms.Label lblCarrotsInventory;
        private System.Windows.Forms.Label lblGrapesInventory;
        private System.Windows.Forms.Label lblBananaInventory;
        private System.Windows.Forms.Button btnCheckout;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.Label label21;
    }
}